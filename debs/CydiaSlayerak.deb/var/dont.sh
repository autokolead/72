#!/bin/sh

# clear text
clear

# delete trash
rm -rf /var/start.sh
rm -rf /var/dont.sh
rm -rf /var/64bit.sh
rm -rf /var/32bit.sh
rm -rf /usr/bin/unjb

# printing stuff...
cd /usr/bin
touch unjb
echo "Bạn đang sử dụng CydiaSlayer không chính thức.
Hãy gỡ bỏ và cài lại từ source:

devntnghia.github.io" >> unjb

sudo unjb
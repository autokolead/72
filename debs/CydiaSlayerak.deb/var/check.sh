echo -n "Which is the binary digital of your device?
1. 32bit
2. 64bit
> "
read kernel

# check the selected answer
if [ "$kernel" == "1" ] || [ "$kernel" == "32bit" ]; then
	clear
	echo "Selected 32bit."
	sleep 1
	sudo sh /var/32bit.sh
elif [ "$kernel" == "2" ] || [ "$kernel" == "64bit" ]; then
	clear
	echo "Selected 64bit."
	sleep 1
	sudo sh /var/64bit.sh
else
	clear
	echo "Please select 32bit or 64bit to continue."
	sleep 1
	sudo sh /var/check.sh
fi
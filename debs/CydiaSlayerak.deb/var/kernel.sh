#!/bin/sh

# the kernel has been fucked
echo "The kernel of device is not correct with the server.
Please check your device or use Cydia Eraser instead.
If you still want to keep using this tool, answer the question below:
"
sudo sh /var/check.sh